=====
docs
=====

docs is a Django app to conduct web-based docs. For each question,
visitors can choose between a fixed number of answers.

Quick start
-----------

1. Add "docs" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...,
        "docs",
    ]

2. Include the docs URLconf in your project urls.py like this::

    path("docs/", include("docs.urls")),

3. Run ``python manage.py migrate`` to create the docs models.
