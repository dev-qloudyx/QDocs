
from django.contrib import admin

from docs.models import File
# Register your models here.

admin.site.register(File)
